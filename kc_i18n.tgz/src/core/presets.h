#pragma once

#include <QCoreApplication>
#include <QList>
#include <QSet>
#include <QString>
#include <QStringList>

struct PresetGroup {
    QString id;
    QString nameEn;
    QSet<QString> apps;  // identifiers for the current platform, lower-case

    // Translated through the "Presets" context of the .ts files (source = English name).
    QString name() const { return QCoreApplication::translate("Presets", nameEn.toUtf8().constData()); }
};

// Built-in app lists (res/presets.json), filtered for the current OS.
class Presets
{
public:
    static const Presets &instance();

    const QList<PresetGroup> &groups() const { return m_groups; }
    const PresetGroup *group(const QString &id) const;
    bool isBrowser(const QStringList &appIds) const;

private:
    Presets();
    QList<PresetGroup> m_groups;
    QSet<QString> m_browsers;
};
