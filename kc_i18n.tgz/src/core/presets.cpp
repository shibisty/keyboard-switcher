#include "presets.h"

#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

namespace {

QLatin1String platformKey()
{
#if defined(Q_OS_WIN)
    return QLatin1String("windows");
#elif defined(Q_OS_MACOS)
    return QLatin1String("macos");
#else
    return QLatin1String("linux");
#endif
}

QSet<QString> toSet(const QJsonValue &v)
{
    QSet<QString> set;
    const QJsonArray arr = v.toArray();
    for (const QJsonValue &item : arr)
        set.insert(item.toString().toLower());
    return set;
}

} // namespace

const Presets &Presets::instance()
{
    static const Presets presets;
    return presets;
}

Presets::Presets()
{
    QFile file(QStringLiteral(":/presets.json"));
    if (!file.open(QIODevice::ReadOnly))
        return;
    const QJsonObject root = QJsonDocument::fromJson(file.readAll()).object();

    const QJsonArray groups = root.value(QLatin1String("groups")).toArray();
    for (const QJsonValue &g : groups) {
        const QJsonObject o = g.toObject();
        PresetGroup group;
        group.id = o.value(QLatin1String("id")).toString();
        group.nameEn = o.value(QLatin1String("name")).toObject().value(QLatin1String("en")).toString();
        group.apps = toSet(o.value(platformKey()));
        if (!group.id.isEmpty() && !group.apps.isEmpty())
            m_groups.append(group);
    }
    m_browsers = toSet(root.value(QLatin1String("browsers")).toObject().value(platformKey()));
}

const PresetGroup *Presets::group(const QString &id) const
{
    for (const PresetGroup &g : m_groups)
        if (g.id == id)
            return &g;
    return nullptr;
}

bool Presets::isBrowser(const QStringList &appIds) const
{
    for (const QString &id : appIds)
        if (m_browsers.contains(id))
            return true;
    return false;
}
